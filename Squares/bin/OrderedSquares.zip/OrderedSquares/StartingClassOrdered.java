package OrderedSquares;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class StartingClassOrdered extends Applet implements Runnable, KeyListener, MouseListener, MouseMotionListener {

	private ArrayList<Square> squares = new ArrayList<Square>();
	private boolean clicked;
	private Point mousePos;
	private boolean dragging;
	private boolean holding;
	private Point posFrom;
	private boolean won;
	
	private Image image;
	private Graphics graphics;
	private Frame frame;
	
	public void init() {
		setSize(601, 601);		//WINDOW SIZE
		setBackground(Color.WHITE);
		setFocusable(true);
		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		frame = (Frame) this.getParent().getParent();
		frame.setTitle("Ordered Squares");
		frame.setResizable(false);
		frame.setLocationRelativeTo(this);
		
	}
	public void start(){		//INITIALIZE EVERYTHING HERE
				
		int x = JOptionPane.showConfirmDialog(null,
				"Randomize board?", "Game Start", JOptionPane.YES_NO_OPTION);
		if (x == 0) {
			ArrayList<Integer> nums = new ArrayList<Integer>();
			for (int i = 0; i < 15; i++) {
				nums.add(i + 1);
			}

			for (int i = 0; i < 4; i++) {
				for (int a = 0; a < 4; a++) {
					int rand = (int) (Math.random() * nums.size());
					if (!(a == 0 && i == 0))
						squares.add(new Square(i * 150 + 75, a * 150 + 75, nums.remove(rand)));
				}
			}
		}
		else {
			for (int i = 0; i < 4; i++) {
				for (int a = 0; a < 4; a++) {
					if (!(a == 0 && i == 0))
						squares.add(new Square(i * 150 + 75, a * 150 + 75, i+1*a*4));
				}
			}
		}
		mousePos = new Point(0,0);
		dragging = false;
		clicked = false;
		holding = false;
		posFrom = new Point(0,0);
		won = false;

		Thread thread = new Thread(this);
		thread.start();
	}
	public void reset(){
		ArrayList <Integer> nums = new ArrayList <Integer>();
		for (int i = 0; i<15; i++){
			nums.add(i+1);
		}
		squares.clear();
		for (int i = 0; i<4; i++) {
			for (int a = 0; a<4; a++) {
				int rand = (int)(Math.random()*nums.size());
				if (!(a==0&&i==0))squares.add(new Square(i*150+75, a*150+75, nums.remove(rand)));
			}
		}
		JOptionPane.showMessageDialog(frame, "Play again?", "Game Won!", 2);
		mousePos = new Point(0,0);
		dragging = false;
		clicked = false;
		holding = false;
		posFrom = new Point(0,0);
		won = false;
	}
	@Override
	public void run() {		//CONSTANTLY UPDATE or LOOK FOR UPDATES HERE
		while(true){
			
			if (clicked&&!holding) {
				for (Square s:squares) {
					if (Math.abs(mousePos.getX()-s.getX())<75&&Math.abs(mousePos.getY()-s.getY())<75) {
						s.setGrabbed(true);
						holding = true;
						//System.out.println("grabbed");
						posFrom = new Point(s.getX(), s.getY());
						break;
					}
				}
			}
			for (Square s:squares) {
				if (s.isGrabbed()) {
					s.setX((int)mousePos.getX());
					s.setY((int)mousePos.getY());
				}
			}
			if (!clicked&&!dragging){
				holding = false;
				for (Square s:squares) {
					if (s.isGrabbed()){
						s.setGrabbed(false);
						boolean validLoc = true;
						for (Square q:squares) {
							if (!s.equals(q)&&(Math.abs(s.getX()-q.getX())<75)&&(Math.abs(s.getY()-q.getY())<75)){
								validLoc = false;
							}
						}
						if (validLoc&&((Math.abs((s.getX()/150*150+75)-posFrom.getX())==150)^(Math.abs((s.getY()/150*150+75)-posFrom.getY())==150))){
							s.setX((s.getX()/150*150+75));
							s.setY((s.getY()/150*150+75));
						}
						else {
							s.setX((int)posFrom.getX());
							s.setY((int)posFrom.getY());
						}
					}
					
				}
			}
			won = true;
			for (Square s:squares) {
				if (!((s.getX()+75)/150+s.getY()/150*4==s.getNumVal())||s.isGrabbed()) won = false;
			}
			
			dragging = false;
			repaint();
			try {
				Thread.sleep(17);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void update(Graphics g) {		//INITIALIZES GRAPHICS - DONT TOUCH except bg color
		if (image == null) {
			image = createImage(this.getWidth(), this.getHeight());
			graphics = image.getGraphics();
		}
		graphics.setColor(Color.WHITE);		//BACKGROUND COLOR
		graphics.fillRect(0, 0, getWidth(), getHeight());
		graphics.setColor(getForeground());
		paint(graphics);
		g.drawImage(image, 0, 0, this);
	}
	@Override
	public void paint(Graphics g) {			//ALL OTHER GRAPHICS
		g.setFont(new Font("Dialog", Font.BOLD, 20));
		for (Square s:squares) {
			if (!s.isGrabbed()){
				g.setColor(new Color(255, 255, 140));
				g.fillRect(s.getX() - 75, s.getY() - 75, 150, 150);
				g.setColor(Color.BLACK);
				g.drawRect(s.getX() - 75, s.getY() - 75, 150, 150);
				g.drawString("" + s.getNumVal(), s.getX() - 10, s.getY());
			}
		}
		g.setFont(new Font("Dialog", Font.BOLD, 23));
		for (Square s:squares) {
			if (s.isGrabbed()) {
				g.setColor(new Color(0, 0, 0, 80));
				g.fillRect(s.getX() - 70, s.getY() - 75, 170, 170);
				g.setColor(new Color(255, 255, 140));
				g.fillRect(s.getX() - 85, s.getY() - 85, 170, 170);
				g.setColor(Color.BLACK);
				g.drawRect(s.getX() - 85, s.getY() - 85, 170, 170);
				g.drawString("" + s.getNumVal(), s.getX() - 9, s.getY());
			}
		}
		g.setColor(Color.RED);
		//g.fillOval((int)mousePos.getX(), (int)mousePos.getY(), 4, 4);
		if (won)g.drawString("You won!", 50, 50);
	}

	@Override
	public void keyPressed(KeyEvent arg0) {		//KEY PRESSED EVENT
		switch (arg0.getKeyCode()){
		case KeyEvent.VK_SPACE:
			//What happens when space is pressed
			break;
		
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		clicked = true;
		dragging = true;
		mousePos = arg0.getPoint();
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		clicked = false;
	}
	@Override
	public void mouseDragged(MouseEvent arg0) {
		mousePos = arg0.getPoint();
		dragging = true;
		
	}
	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
